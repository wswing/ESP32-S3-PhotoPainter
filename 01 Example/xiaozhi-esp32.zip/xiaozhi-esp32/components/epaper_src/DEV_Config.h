#ifndef _DEV_CONFIG_H_
#define _DEV_CONFIG_H_




#define UBYTE   uint8_t
#define UWORD   uint16_t
#define UDOUBLE uint32_t




#endif